<?php

namespace hcf\handler\package;

use hcf\HCFLoader;
use hcf\player\Player;

use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\VanillaItems;
use pocketmine\event\Listener;
use pocketmine\item\LegacyStringToItemParser;
use pocketmine\item\Item;
use pocketmine\block\utils\DyeColor;

class PackageListener implements Listener {

    public static array $items;
    
    public static function givePartner(Player $player, int $int): void {
        $partner = VanillaBlocks::ENDER_CHEST()->asItem()->setCount($int);
        $partner->setCustomName("§aPartnerPackages");
        $partner->setLore(["\n§r§7Right click to receive random §aablitys.\n§ePurchase at §3https://" . HCFLoader::getInstance()->getConfig()->get('tebex')]);
        $partner->addEnchantment(new EnchantmentInstance(VanillaEnchantments::INFINITY(), 1));
        
        $player->getInventory()->addItem($partner);
        $player->sendMessage("§aYou have received a PartnerPackages!");
    }
    
    public function onItemUse(PlayerItemUseEvent $event): void {
        $player = $event->getPlayer();
        $item = $event->getItem();

        if ($item->getCustomName() !== "§aPartnerPackages") {
            return;
        }

        $item->setCount($item->getCount() - 1);
        $player->getInventory()->setItemInHand($item);
        
        if (count(self::$items) == 0)
                return;

            if (!$player->getInventory()->canAddItem($this->getRandomItem())) {
                $player->sendMessage("§4Your inventory is full!");
                return;
            }

            $item1 = $this->getRandomItem();
            $player->getInventory()->addItem($item1);

    }
    
    public function onBlockInteract(PlayerInteractEvent $event): void {
        $item = $event->getItem();
        $player = $event->getPlayer();

        if ($item->getCustomName() !== "§aPartnerPackages") {
            return;
        }

        if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
            $event->cancel();
        }
    }

    public function getRandomItem(): Item
    {
        return self::$items[array_rand(self::$items)];
    }

    public static function setItems() {
    //------------------Melonite----------------
        $melonite = VanillaItems::MELON()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::INFINITY(), 1));
        $melonite->setCustomName("§7[§6!§7] §dMelonite");
        $melonite->setLore([
            "§r§f",
            "§r§7Use this item to get Resistance III, Regeneration III",
            "§r§7and Absorpcion II for 3 seconds",
            "§r§a",
            "§r§ePurchase at §3" . HCFLoader::getInstance()->getConfig()->get('tebex')]);
        $melonite->getNamedTag()->setString("Abilities","Melonite");
        //------------------------------------------
        
        //----------------FlowerTank----------------
        $flowertank = self::getItem(38, 0)->addEnchantment(new EnchantmentInstance(VanillaEnchantments::INFINITY(), 1));
        $flowertank->setCustomName("§7[§6!§7] §cFlower Tank");
        $flowertank->setLore([
            "§r§f",
            "§r§7Use this item to get Resistance III, Regeneration IV",
            "§r§7and Absorpcion II for 3 seconds",
            "§r§a",
            "§r§ePurchase at §3" . HCFLoader::getInstance()->getConfig()->get('tebex')]);
        $flowertank->getNamedTag()->setString("Abilities","FlowerTank");
        //------------------------------------------
        
        //------------------RiskyMode----------------
        $risky = VanillaItems::GOLD_NUGGET()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::INFINITY(), 1));
        $risky->setCustomName("§7[§6!§7] §gRiskyMode");
        $risky->setLore([
        "§r§f",
        "§r§7Gives you strength 3 for 7 seconds",
        "§r§a",
        "§r§ePurcharse at §3" . HCFLoader::getInstance()->getConfig()->get('tebex')]);
       $risky->getNamedTag()->setString("Abilities","RickyMode");
        //------------------------------------------
        
        //------------------Vortex----------------
        $vortex = VanillaItems::DYE()->setColor(DyeColor::ORANGE())->addEnchantment(new EnchantmentInstance(VanillaEnchantments::INFINITY(), 1));
        $vortex->setCustomName("§7[§6!§7] §6VortexEye");
        $vortex->setLore([
        "§r§f",
        "§r§7Teleport to your enemy and",
        "§r§7Gives you Strength 2 and",
        "§r§7Resistance 2 for 10 Seconds",
        "§r§a",
        "§r§ePurcharse at §3" . HCFLoader::getInstance()->getConfig()->get('tebex')]);
        $vortex->getNamedTag()->setString("Abilities","VortexEye");
         //------------------------------------------  
        
        //------------------AntiDropDown----------------
        $antidropdown = VanillaBlocks::STONE()->asItem()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::INFINITY(), 1));
        $antidropdown->setCustomName("§7[§6!§7] §bAntiDropDown");
        $antidropdown->setLore([
            "§f",
            "§7Hit a player 3 times in a row",
            "§7to prevent them placing/breaking blocks",
            "§7or interacting with openables for 20 seconds",
            "§a",
            "§ePurcharse at §3" . HCFLoader::getInstance()->getConfig()->get('tebex')]);
        $antidropdown->getNamedTag()->setString("Abilities","AntiDropDown");
        //------------------------------------------
        
        //------------------HogRider----------------
        $hogrider = VanillaItems::RAW_PORKCHOP()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::INFINITY(), 1));
        $hogrider->setCustomName("§7[§6!§7] §bHogRider");
        $hogrider->setLore([
            "§f",

            "§7Hit a player 3 times in a row",
            "§7to prevent them placing/breaking blocks",
            "§7or interacting with openables for 20 seconds",
            "§a",
            "§ePurcharse at §3" . HCFLoader::getInstance()->getConfig()->get('tebex')]);
        $hogrider->getNamedTag()->setString("Abilities","HogRider");
        //------------------------------------------

        //------------------ExoticBone----------------
        $exoticbone = VanillaItems::BONE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::INFINITY(), 1));
        $exoticbone->setCustomName("§7[§6!§7] §aAntiTrapper");
        $exoticbone->setLore([
            "§f",
            "§7Hit a player 3 times in a row",
            "§7to prevent them placing/breaking blocks",
            "§7or interacting with openables for 20 seconds",
            "§a",
            "§ePurcharse at §3" . HCFLoader::getInstance()->getConfig()->get('tebex')]);
        $exoticbone->getNamedTag()->setString("Abilities","ExoticBone");
        //------------------------------------------
        
                //------------------ExoticBone----------------
        $medikit = VanillaItems::PUMPKIN_PIE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::INFINITY(), 1));
        $medikit->setCustomName("§7[§6!§7] §cMedikit");
        $medikit->setLore([
            "§f",
            "§7Hit a player 3 times in a row",
            "§7to prevent them placing/breaking blocks",
            "§7or interacting with openables for 20 seconds",
            "§a",
            "§ePurcharse at §3" . HCFLoader::getInstance()->getConfig()->get('tebex')]);
        $medikit->getNamedTag()->setString("Abilities","Medikit");
        //------------------------------------------

        //------------------EffectDisabler----------------
        $effectdisabler = VanillaItems::SLIMEBALL()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::INFINITY(), 1));
        $effectdisabler->setCustomName("§7[§6!§7] §aEffects Disabler");
        $effectdisabler->setLore([
            "",
            "§7hit a player with the item",
            "§7to clear the effects of the other player!",
            "§f",
            "§ePurcharse at §3" . HCFLoader::getInstance()->getConfig()->get('tebex')]);
        $effectdisabler->getNamedTag()->setString("Abilities","EffectDisabler");
        //------------------------------------------

        //------------------PortableBard----------------
        $portalebard = VanillaItems::ZOMBIE_SPAWN_EGG()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::INFINITY(), 1));
        $portalebard->setCustomName("§7[§6!§7] §dPortable Bard");
        $portalebard->setLore([
            "§f",
            "§7Using the spawn egg will create a witch and they hold negative effects to your enemies!",
            "§a",
            "§ePurcharse at §3" . HCFLoader::getInstance()->getConfig()->get('tebex')]);
        $portalebard->getNamedTag()->setString("Abilities","PortableBard");
        //------------------------------------------

        //------------------Freeze----------------
        $freeze = VanillaBlocks::ICE()->asItem()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::INFINITY(), 1));
        $freeze->setCustomName("§7[§6!§7] §bFreeze");
        $freeze->setLore([
            "§f",
            "§7When shooting an enemy, they will be completely frozen for a certain time",
            "§a",
            "§ePurcharse at §3" . HCFLoader::getInstance()->getConfig()->get('tebex')]);
        $freeze->getNamedTag()->setString("Abilities","Freeze");
        //------------------------------------------

        //------------------SecondChance----------------
        $secondchance = VanillaItems::GHAST_TEAR()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::INFINITY(), 1));
        $secondchance->setCustomName("§7[§6!§7] §bSecondChance");
        $secondchance->setLore([
            "§f",
            "§7This item will remove the enderpearl cooldown",
            "§7to give you a second chance",
            "§2",
            "§ePurcharse at §3" . HCFLoader::getInstance()->getConfig()->get('tebex')]);
        $secondchance->getNamedTag()->setString("Abilities","SecondChance");
        //------------------------------------------

        //------------------Switcher----------------
        $switcher = VanillaItems::SNOWBALL()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::INFINITY(), 1));
        $switcher->setCustomName("§7[§6!§7] §bSwitcher");
        $switcher->setLore([
            "§a",
            "§7thorw this snowball to your enemy to change",
            "§7your position with him",
            "§f",
            "§ePurcharse at §3" . HCFLoader::getInstance()->getConfig()->get('tebex')]);
        $switcher->getNamedTag()->setString("Abilities","Switcher");
        //------------------------------------------

        //------------------Strength----------------
        $strenght = VanillaItems::BLAZE_POWDER()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::INFINITY(), 1));
        $strenght->setCustomName("§7[§6!§7] §cStrength II");
        $strenght->setLore([
            "§f",
            "§7this item will give you strength II",
            "§7for a few seconds",
            "§3",
            "§ePurcharse at §3" . HCFLoader::getInstance()->getConfig()->get('tebex')]);
        $strenght->getNamedTag()->setString("Abilities","Strength");
        //------------------------------------------

        //------------------jumpboost----------------
        $jumpboost = VanillaItems::FEATHER()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::INFINITY(), 1));
        $jumpboost->setCustomName("§7[§6!§7] §6JumpBoost");
        $jumpboost->setLore([
            "§2",
            "§f§7this item will give you Jump Boost VII for",
            "§7a few seconds",
            "§f",
            "§ePurcharse at §3" . HCFLoader::getInstance()->getConfig()->get('tebex')]);
        $jumpboost->getNamedTag()->setString("Abilities","JumpBoost");
        //------------------------------------------

        //------------------speed----------------
        $speed = VanillaItems::SUGAR()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::INFINITY(), 1));
        $speed->setCustomName("§7[§6!§7] §6Speed");
        $speed->setLore([
            "§2",
            "§7this item will give you Speed II for",
            "§7a few seconds",
            "§f",
            "§ePurcharse at §3" . HCFLoader::getInstance()->getConfig()->get('tebex')]);
        $speed->getNamedTag()->setString("Abilities","Speed");
        //------------------------------------------

        //------------------resistance----------------
        $resistance = VanillaItems::IRON_INGOT()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::INFINITY(), 1));
        $resistance->setCustomName("§7[§6!§7] §dResistance III");
        $resistance->setLore([
            "§f",
            "§7this item will give you Resistence III for",
            "§7a few seconds",
            "§f",
            "§ePurcharse at §3" . HCFLoader::getInstance()->getConfig()->get('tebex')]);
        $resistance->getNamedTag()->setString("Abilities","Resistance");
        //------------------------------------------

        //------------------regeneration----------------
        $regeneration = VanillaItems::GOLD_INGOT()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::INFINITY(), 1));
        $regeneration->setCustomName("§7[§6!§7] §6Regeneration");
        $regeneration->setLore([
            "§2",
            "§7this item will give you Regeneration III for",
            "§7a few seconds",
            "§f",
            "§ePurcharse at §3" . HCFLoader::getInstance()->getConfig()->get('tebex')]);
        $regeneration->getNamedTag()->setString("Abilities","Regeneration");
        //------------------------------------------

        //------------------ballofrange----------------
        $ballofrange = VanillaItems::EGG()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::INFINITY(), 1));
        $ballofrange->setCustomName("§7[§6!§7] §cBall of Range");
        $ballofrange->setLore([
            "§f",
            "§7when you throw this egg, the members of your",
            "§7faction that are near will receive strength II",
            "§7and Resistence III for a few seconds, and the",
            "§7enemies will receive Wither II",
            "§a",
            "§ePurchase at §3" . HCFLoader::getInstance()->getConfig()->get('tebex')]);
        $ballofrange->getNamedTag()->setString("Abilities","BallOfRange");
        //------------------------------------------

        //------------------Berserk----------------
        $berserk = VanillaItems::DYE()->setColor(DyeColor::RED())->addEnchantment(new EnchantmentInstance(VanillaEnchantments::INFINITY(), 1));
        $berserk->setCustomName("§7[§6!§7] §cBerserk");
        $berserk->setLore([
            "§f",
            "§7Use this item to get Strength I, Resistance II",
            "§7and Speed II for seconds",
            "§a",
            "§ePurchase at §3" . HCFLoader::getInstance()->getConfig()->get('tebex')]);
        $berserk->getNamedTag()->setString("Abilities","Berserk");
        //------------------------------------------

        //------------------NinjaStar----------------
        $ninjastar = VanillaItems::NETHER_STAR()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::INFINITY(), 1));
        $ninjastar->setCustomName("§7[§6!§7] §bNinja Star");
        $ninjastar->setLore([
            "§f",
            "§7Teleports you to the last person who",
            "§7hit you in the last 15 seconds!",
            "§a",
            "§ePurchase at §3" . HCFLoader::getInstance()->getConfig()->get('tebex')]);
        $ninjastar->getNamedTag()->setString("Abilities","NinjaStar");
        //------------------------------------------

        //---------------------RePot-------------------
        $potion = VanillaItems::GLASS_BOTTLE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::INFINITY(), 1));
        $potion->setCustomName("§7[§6!§7] §bRePot");
        $potion->setLore([
            "§f",
            "§7Fills your entire inventory of health potions 2",
            "§a",
            "§ePurchase at §3" . HCFLoader::getInstance()->getConfig()->get('tebex')]);
        $potion->getNamedTag()->setString("Abilities","Potion");
        //----------------------------------------------
        
        //------------------StromBreaker----------------
        $strombreaker = VanillaItems::GOLDEN_AXE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::INFINITY(), 1));
        $strombreaker->setCustomName("§7[§6!§7] §eStromBreaker");
        $strombreaker->setLore([
            "§f",
            "§7Hit a enemy with this item and",
            "§7in 3 seconds the helmet",
            "§a",
            "§ePurchase at §3" . HCFLoader::getInstance()->getConfig()->get('tebex')]);
        $strombreaker->getNamedTag()->setString("Abilities","Strombreaker");
        //------------------------------------------
        self::$items = [
            $exoticbone,
            $effectdisabler,       
            $portalebard,
            $freeze,
            $secondchance,
            $risky,
            $switcher,
            $strenght,
            $jumpboost,
            $speed,
            $resistance,
            $regeneration,
            $berserk,
            $ninjastar,
            $potion,
            $strombreaker,
            $flowertank,
            $ballofrange,
            $melonite,
            $hogrider,
            $medikit,];
    }
    
    public static function getItem($id, $meta = 0, $count = 1): Item {
        return LegacyStringToItemParser::getInstance()->parse("{$id}:{$meta}")->setCount($count);
    }
}