<?php  
  
declare(strict_types=1);  
  
namespace hcf\handler\kit\classes\presets;  
  
use hcf\handler\kit\classes\HCFClass;  
use hcf\HCFLoader; // Para el Scheduler y Cooldowns
use hcf\player\Player;  
use hcf\abilities\items\IceSphere; // Habilidad de esfera de hielo
use pocketmine\entity\effect\EffectInstance;  
use pocketmine\entity\effect\VanillaEffects;  
use pocketmine\event\player\PlayerItemUseEvent;  
use pocketmine\item\Item;  
use pocketmine\item\VanillaItems;  
use pocketmine\block\VanillaBlocks; 
use pocketmine\utils\TextFormat;  
// CORRECCIÓN: Importamos las clases de eventos para evitar el error de compilación
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByChildEntityEvent;

class Yeti extends HCFClass  
{  
    
    // Asegúrate de que este ID corresponda al de tu servidor (ej. 5 o el siguiente libre)
    public const YETI = 5; 
      
    /** * Yeti construct.  
     */  
    public function __construct()  
    {  
        // Usamos el ID entero, como requiere el constructor de HCFClass
        parent::__construct(self::YETI); 
    }  
      
    /** * @return Item[]  
     */  
    public function getArmorItems(): array  
    {  
        // Casco: Cuero, Pechera: Diamante, Pantalones: Diamante, Botas: Cuero
        return [  
            VanillaItems::LEATHER_CAP(),  
            VanillaItems::DIAMOND_CHESTPLATE(),  
            VanillaItems::DIAMOND_LEGGINGS(),  
            VanillaItems::LEATHER_BOOTS()  
        ];  
    }  
      
    /** * @return EffectInstance[]  
     */  
    public function getEffects(): array  
    {  
        return [  
            new EffectInstance(VanillaEffects::RESISTANCE(), 20 * 15, 1), // Resistencia II
            new EffectInstance(VanillaEffects::STRENGTH(), 20 * 15, 0),  // Fuerza I
            new EffectInstance(VanillaEffects::SPEED(), 20 * 15, 1)      // Velocidad II
        ];  
    }  
      
    /** * @param PlayerItemUseEvent $event  
     */  
    public function handleItemUse(PlayerItemUseEvent $event): void  
    {  
        $player = $event->getPlayer();  
        $item = $player->getInventory()->getItemInHand();  
  
        if (!$player instanceof Player || $player->getClass() === null || $player->getClass()->getTypeId() !== self::YETI) {  
            return;  
        }  

        // CORRECCIÓN: Usamos VanillaBlocks::ICE() y lo convertimos a Item para la comparación de ID.
        if ($item->getTypeId() === VanillaBlocks::ICE()->asItem()->getTypeId()) {
            
            // --- Verificaciones de Cooldown y Claim (Asume que los métodos existen) ---
            if ($player->getSession()->getCooldown('ability.IceSphere') !== null) {  
                $player->sendMessage(TextFormat::colorize("§cNo puedes usar la §bIce Sphere§c por §l" . \hcf\utils\time\Timer::format($player->getSession()->getCooldown("ability.IceSphere")->getTime())));
                $event->cancel();  
                return;  
            }  
  
            if ($player->getSession()->getCooldown('ability.global') !== null) {  
                $player->sendMessage(TextFormat::colorize("§cTienes un cooldown activo de &l&5Partner Item &r§c."));  
                $event->cancel();  
                return;  
            }  

            if ($player->getCurrentClaim() === 'Spawn') {  
                 $player->sendMessage(TextFormat::colorize("&cNo puedes usar habilidades en la zona de Spawn."));  
                 $event->cancel();  
                 return;  
            }  
                      
            if ($player->getSession()->getCooldown('starting.timer') !== null || $player->getSession()->getCooldown('pvp.timer') !== null) {  
                $player->sendMessage(TextFormat::colorize("&cNo puedes usar habilidades mientras tengas un timer de protección."));
                $event->cancel();  
                return;  
            }
            // --- Fin de Verificaciones ---
  
            $player->sendMessage(TextFormat::colorize("§6Has activado tu habilidad §bIce Sphere"));  
                      
            // Aplicar Cooldowns
            $player->getSession()->addCooldown('ability.IceSphere', '§bIce Sphere&r&7: &c', 120); 
            $player->getSession()->addCooldown('ability.global', '&5Partner Item&r&7: &c', 10); 
            
            // Ejecutar la habilidad
            (new IceSphere())->generateSphere($player); 
  
            // Remover ítem y cancelar evento de colocación
            $item->pop();  
            $player->getInventory()->setItemInHand($item);  
            $event->cancel();
        }  
    }  
    
    /** * @param EntityDamageEvent $event  
     * Este método se deja vacío, pero ahora usa la clase de evento correcta. 
     */  
    public function handleDamage(EntityDamageEvent $event): void {}
    
    /** * @param EntityDamageByChildEntityEvent $event  
     * Este método se deja vacío, pero ahora usa la clase de evento correcta.
     */  
    public function handleDamageByChildEntity(EntityDamageByChildEntityEvent $event): void {}
}