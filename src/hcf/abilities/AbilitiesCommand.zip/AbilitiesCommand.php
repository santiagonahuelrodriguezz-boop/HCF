<?php

declare(strict_types=1);

namespace hcf\abilities;

use hcf\HCFLoader;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\item\VanillaItems;
use pocketmine\item\ItemFactory;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\block\VanillaBlocks;
use pocketmine\block\utils\DyeColor;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;

class AbilitiesCommand extends Command
{
    public function __construct()
    {
        parent::__construct('abilities', 'View all Demon HCF abilities');
        $this->setPermission("abilities.command.use");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void
    {
        if (!$sender instanceof Player) return;

        $menu = InvMenu::create(InvMenu::TYPE_CHEST);
        $menu->setName("§l§cDEMON §fAbilities");

        $menu->setInventoryCloseListener(function(Player $player, $item) : void {});

        $menu->setListener(function(InvMenuTransaction $transaction) : InvMenuTransactionResult {
            return $transaction->discard();
        });

        $inventory = $menu->getInventory();

        $items = [];

        // ------------------ ITEMS ------------------
        $Samurai = VanillaItems::DIAMOND_SWORD();
        $Samurai->setCustomName("§r§l§1Samurai");
        $Samurai->setLore([
            "§r§f",
            "§r§7Teleport to your enemy and",
            "§r§7Gives you Strength 2 and",
            "§r§7Resistance 2 for 10 Seconds",
            "§r§a",
            "§r§ePurcharse at §b" . HCFLoader::getInstance()->getConfig()->get('tebex')
        ]);
        $items[] = $Samurai;

        $FairFight = VanillaItems::DYE()->setColor(DyeColor::GRAY());
        $FairFight->setCustomName("§r§l§7Fair §fFight");
        $FairFight->setLore([
            "§r§f",
            "§r§7Use this item to weaken your nearest opponent.",
            "§r§7It will temporarily reduce their armor to §cProtection I",
            "§r§7for §f10 seconds§7, making fights fairer!",
            "§r§a",
            "§r§ePurchase at §b" . HCFLoader::getInstance()->getConfig()->get('tebex')
        ]);
        $items[] = $FairFight;

        $Risky = VanillaItems::GOLD_NUGGET();
        $Risky->setCustomName("§r§l§gRiskyMode");
        $Risky->setLore([
            "§r§f",
            "§r§7Gives you strength 3 for 7 seconds",
            "§r§a",
            "§r§ePurcharse at §b" . HCFLoader::getInstance()->getConfig()->get('tebex')
        ]);
        $items[] = $Risky;

        $Refill = VanillaItems::POTION();
        $Refill->setCustomName("§r§l§bPotionRefill");
        $Refill->setLore([
            "§r§f",
            "§r§7Refills your inventory of instant health potions",
            "§r§a",
            "§r§ePurcharse at §b" . HCFLoader::getInstance()->getConfig()->get('tebex')
        ]);
        $items[] = $Refill;

        $Invi = VanillaItems::INK_SAC();
        $Invi->setCustomName("§r§l§bInvisibility");
        $Invi->setLore([
            "§r§f",
            "§r§7Gives you invisibility for a 10 seconds",
            "§r§a",
            "§r§ePurcharse at §b" . HCFLoader::getInstance()->getConfig()->get('tebex')
        ]);
        $items[] = $Invi;

        $Combo = VanillaItems::PUFFERFISH();
        $Combo->setCustomName("§r§l§4Combo Ability");
        $Combo->setLore([
            "§r§f",
            "§r§7Gives you strength 2 for the number of hits you give",
            "§r§a",
            "§r§ePurcharse at §b" . HCFLoader::getInstance()->getConfig()->get('tebex')
        ]);
        $items[] = $Combo;

        $FocusMode = VanillaItems::GOLD_NUGGET();
        $FocusMode->setCustomName("§r§l§cFocusMode");
        $FocusMode->setLore([
            "§r§f",
            "§r§7Increase ur strength for a few seconds",
            "§r§a",
            "§r§ePurcharse at §b" . HCFLoader::getInstance()->getConfig()->get('tebex')
        ]);
        $items[] = $FocusMode;

        $SullCrat = VanillaItems::FIRE_CHARGE();
        $SullCrat->setCustomName("§r§l§4SullCrat");
        $SullCrat->setLore([
            "§r§f",
            "§r§7Use this item and after 5s",
            "§r§7Change the fence gate for air when it touches it.",
            "§r§a",
            "§r§ePurcharse at §b" . HCFLoader::getInstance()->getConfig()->get('tebex')
        ]);
        $items[] = $SullCrat;

        $ExoticBone = VanillaItems::BONE();
        $ExoticBone->setCustomName("§r§l§bExoticBone");
        $ExoticBone->setLore([
            "§r§f",
            "§r§7Hit a player 3 times in a row",
            "§r§7to prevent them placing/breaking blocks",
            "§r§7or interacting with openables for 20 seconds",
            "§r§a",
            "§r§ePurcharse at §b" . HCFLoader::getInstance()->getConfig()->get('tebex')
        ]);
        $items[] = $ExoticBone;

        // ------------------ Items con NamedTag ------------------
        $PearlCooldown = VanillaItems::STICK();
        $PearlCooldown->setCustomName("§r§l§7AntiPerl");
        $PearlCooldown->setLore([
            "§r",
            "§r§7Hit a player with this stick",
            "§r§7to prevent them from using Ender Pearls for 15 seconds!",
            "§r§f",
            "§r§ePurchase at §b" . HCFLoader::getInstance()->getConfig()->get('tebex')
        ]);
        $PearlCooldown->getNamedTag()->setString("Abilities","PearlCooldown");
        $items[] = $PearlCooldown;

        $EffectDisabler = VanillaItems::SLIMEBALL();
        $EffectDisabler->setCustomName("§r§l§aEffects Disabler");
        $EffectDisabler->setLore([
            "§r",
            "§r§7hit a player with the item",
            "§r§7to clear the effects of the other player!",
            "§r§f",
            "§r§ePurcharse at §b" . HCFLoader::getInstance()->getConfig()->get('tebex')
        ]);
        $EffectDisabler->getNamedTag()->setString("Abilities","EffectDisabler");
        $items[] = $EffectDisabler;

        $FrezzerGun = VanillaItems::SNOWBALL();
        $FrezzerGun->setCustomName("§r§l§4Demon §bBall");
        $FrezzerGun->setLore([
            "§r§f",
            "§r§7When shooting an enemy, they will be completely frozen for a certain time",
            "§r§a",
            "§r§ePurcharse at §b" . HCFLoader::getInstance()->getConfig()->get('tebex')
        ]);
        $FrezzerGun->getNamedTag()->setString("Abilities","FrezzerGun");
        $items[] = $FrezzerGun;

        $SecondChance = VanillaItems::GOLDEN_APPLE();
        $SecondChance->setCustomName("§r§l§bSecondChance");
        $SecondChance->setLore([
            "§r§f",
            "§r§7This item will remove the enderpearl cooldown",
            "§r§7to give you a second chance",
            "§r§2",
            "§r§ePurcharse at §b" . HCFLoader::getInstance()->getConfig()->get('tebex')
        ]);
        $SecondChance->getNamedTag()->setString("Abilities","SecondChance");
        $items[] = $SecondChance;

        // Agregar el resto de abilities con NamedTag
        $AbilityDisabler = VanillaItems::POISONOUS_POTATO();
        $AbilityDisabler->setCustomName("§r§l§aAbility Disabler");
        $AbilityDisabler->setLore([
            "§r§f",
            "§r§7When you use this item every player within",
            "§r§715 blocks of you wont be able",
            "§r§7to use any pp item for 90 seconds",
            "§r§2",
            "§r§ePurcharse at §b" . HCFLoader::getInstance()->getConfig()->get('tebex')
        ]);
        $AbilityDisabler->getNamedTag()->setString("Abilities","AbilityDisabler");
        $items[] = $AbilityDisabler;

        $Switcher = VanillaItems::SNOWBALL();
        $Switcher->setCustomName("§r§l§bSwitcher");
        $Switcher->setLore([
            "§r§a",
            "§r§7Throw this snowball to your enemy to change",
            "§r§7your position with him",
            "§r§f",
            "§r§ePurcharse at §b" . HCFLoader::getInstance()->getConfig()->get('tebex')
        ]);
        $Switcher->getNamedTag()->setString("Abilities","Switcher");
        $items[] = $Switcher;

        // ...continúa así agregando todos los demás items con $items[] = $nombreItem;

        // ------------------ Agregar items al inventario ------------------
        foreach ($items as $item) {
            $inventory->addItem($item);
        }

        $menu->send($sender);
    }
}
