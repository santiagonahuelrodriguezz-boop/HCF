<?php

namespace hcf\abilities\items;

use hcf\session\extras\SessionFreeze;
use hcf\abilities\task\ImmobilizerTask;
use hcf\HCFLoader;
use hcf\player\Player;
use hcf\utils\Utils;
use hcf\utils\time\Timer;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Listener;
use pocketmine\item\VanillaItems;
use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat;

class Freeze implements Listener
{
    public function onDamage(EntityDamageByEntityEvent $event): void
    {
        
        $entity = $event->getEntity();
        $player = $event->getDamager();
        if ($entity instanceof Player && $player instanceof Player) {
            $item = $player->getInventory()->getItemInHand();
            if ($item->getNamedTag()->getTag("Abilities") !== null) {
                if ($item->getNamedTag()->getString("Abilities") === "Freeze") {
                    if ($player->getSession()->getCooldown('ability.freeze') === null) {
                        if ($player->getSession()->getCooldown('ability.global') === null) {

                            if ($player->getSession()->getCooldown('starting.timer') !== null || $player->getSession()->getCooldown('pvp.timer') !== null) {
                                return;
                            }

                            if ($entity->getSession()->getCooldown('starting.timer') !== null || $entity->getSession()->getCooldown('pvp.timer') !== null) {
                                return;
                            }

                            if ($entity->getSession()->getFaction() !== null && $player->getSession()->getFaction() !== null) {
                                if ($entity->getSession()->getFaction() === $player->getSession()->getFaction()) {
                                    $player->sendMessage(TextFormat::colorize("§eYou cannot hurt §2" . $entity->getName() . "§e."));
                                    $event->cancel();
                                    return;
                                }
                            }

                            if ($player->getCurrentClaim() === 'Spawn') {
                                return;
                            }
                            Utils::PlaySound($player, "random.orb", 1, 1);
                            $player->sendMessage("§6You have activated §bFreeze");
                            $player->getSession()->addCooldown('ability.freeze', ' §f| §bFreeze§7: §f', 120);
                            $player->getSession()->addCooldown('ability.global', ' §f| §5Partner Item§7: §f', 5);

                            SessionFreeze::addFreeze($entity);
                            $entity->sendTitle("§l§bYouu were frozen");
                            new ImmobilizerTask($entity);                   
                           
                            
                            if($item->getCount() > 1){
                                $item->setCount($item->getCount() - 1);
                            } else {
                                $item = VanillaItems::AIR();
                            }
                            $player->getInventory()->setItemInHand($item);

                        } else {
                            $player->sendMessage("§6you have cooldown of §dPartner Item §f" . Timer::format($player->getSession()->getCooldown("ability.global")->getTime()));
                        }
                    } else {
                        $player->sendMessage("§cYou haven't Freeze in the last " . Timer::format($player->getSession()->getCooldown("ability.freeze")->getTime()));
                    }
                }
            }
        }
    }
    
    public function onMove(PlayerMoveEvent $e):void
    {
        if(SessionFreeze::isFreeze($e->getPlayer()))
        $e->cancel();
    }

    public function onHit(EntityDamageByEntityEvent $e):void
    {
        $player = $e->getEntity();
        if($player instanceof Player)
        SessionFreeze::hitFreeze($player);
    }
}