<?php

namespace hcf\abilities\task;

use hcf\session\extras\SessionFreeze;
use hcf\HCFLoader;
use pocketmine\player\Player;
use pocketmine\scheduler\Task;
use pocketmine\entity\Entity;

class ImmobilizerTask extends Task {
    private $time = 5;
    public function __construct(private Player $player) {
        $this->setHandler(HCFLoader::getInstance()->getScheduler()->scheduleRepeatingTask($this,20));
    }

     public function onRun(): void {
        $this->time--;
        $this->player->sendSubTitle("§ffor§c " . $this->time . " §fseconds");
        if(!$this->player->isOnline() || $this->time <= 0)
        {
            SessionFreeze::removeFreeze($this->player);
            $this->getHandler()->cancel();
            return;
        }
    }
}