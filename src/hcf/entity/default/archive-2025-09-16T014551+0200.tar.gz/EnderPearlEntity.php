<?php

declare(strict_types=1);

namespace hcf\entity\default;

use pocketmine\block\Block;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\FenceGate;
use pocketmine\block\Slab;
use pocketmine\entity\Entity;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\projectile\Throwable;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\math\RayTraceResult;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use pocketmine\player\Player;
use pocketmine\timings\Timings;
use pocketmine\utils\TextFormat;
use pocketmine\world\Position;
use pocketmine\world\sound\EndermanTeleportSound;

class EnderPearlEntity extends Throwable
{
    protected Vector3 $position;

    // 🔹 Gravedad y drag para caída natural
    protected float $gravity = 0.15;
    protected float $drag = 0.98;

    public static function getNetworkTypeId(): string
    {
        return EntityIds::ENDER_PEARL;
    }

    // 🔹 Velocidad inicial de la pearl
    protected function getInitialVelocity(): Vector3 {
        $owner = $this->getOwningEntity();
        if(!$owner instanceof Player) return new Vector3(0,0,0);

        return $owner->getDirectionVector()->multiply(2.1); // velocidad y alcance vanilla
    }

    public function spawnToAll(): void
    {
        parent::spawnToAll();
        // 🔹 Aplicar la velocidad inicial al proyectil
        $this->motion = $this->getInitialVelocity();
    }

    public function onUpdate(int $currentTick): bool
    {
        if ($this->closed) return false;

        $this->readPosition();

        $tickDiff = $currentTick - $this->lastUpdate;
        if ($tickDiff <= 0) return true;

        $this->lastUpdate = $currentTick;

        if (!$this->isAlive()) {
            if ($this->onDeathUpdate($tickDiff)) {
                $this->flagForDespawn();
            }
            return true;
        }

        $this->timings->startTiming();

        if ($this->hasMovementUpdate()) {
            $this->tryChangeMovement();

            if (abs($this->motion->x) <= self::MOTION_THRESHOLD) $this->motion->x = 0;
            if (abs($this->motion->y) <= self::MOTION_THRESHOLD) $this->motion->y = 0;
            if (abs($this->motion->z) <= self::MOTION_THRESHOLD) $this->motion->z = 0;

            if ($this->motion->x !== 0 || $this->motion->y !== 0 || $this->motion->z !== 0) {
                $this->move($this->motion->x, $this->motion->y, $this->motion->z);
            }

            $this->forceMovementUpdate = false;
        }

        $this->updateMovement();

        Timings::$entityBaseTick->startTiming();
        $hasUpdate = $this->entityBaseTick($tickDiff);
        Timings::$entityBaseTick->stopTiming();

        $this->timings->stopTiming();

        return ($hasUpdate or $this->hasMovementUpdate());
    }

    protected function readPosition(): void
    {
        $new = $this->getPosition();
        if ($new->distanceSquared($this->getPositionPlayer()) > 1) {
            $this->setPositionPlayer(new Vector3($this->getPosition()->x, (int)$this->getPosition()->y, $this->getPosition()->z));
        }
    }

    protected function getPositionPlayer(): Vector3
    {
        return $this->position ?? new Vector3(0, 0, 0);
    }

    protected function setPositionPlayer(Vector3 $position): void
    {
        $this->position = $position;
    }

    protected function getInitialSizeInfo(): EntitySizeInfo
    {
        return new EntitySizeInfo(0.8, 0.8, 0.8);
    }

    protected function onHitEntity(Entity $entityHit, RayTraceResult $hitResult): void
    {
        if ($this->getOwningEntity() instanceof Player) {
            $this->getOwningEntity()->teleport($entityHit->getPosition());
            $this->getOwningEntity()->attack(new EntityDamageEvent($this->getOwningEntity(), EntityDamageEvent::CAUSE_FALL, 2));
            $this->getWorld()->addSound($this->getOwningEntity()->getPosition(), new EndermanTeleportSound());
        }
        $this->flagForDespawn();
    }

    protected function onHitBlock(Block $blockHit, RayTraceResult $hitResult): void
    {
        if ($this->getOwningEntity()) {
            $this->teleportAt();
        } else {
            $this->flagForDespawn();
        }
    }

    protected function teleportAt(): void
    {
        $player = $this->getOwningEntity();
        if (!$player instanceof Player || !$player->isOnline()) {
            $this->flagForDespawn();
            return;
        }

        if ($this->isFence()) {
            $this->flagForDespawn();
            $player->sendTip(TextFormat::YELLOW . "Your EnderPearl was returned, to avoid glitching");
            return;
        }

        // 🔹 Teletransporte final al lugar donde cae la pearl
        $player->teleport($this->getPositionPlayer());
        $player->attack(new EntityDamageEvent($player, EntityDamageEvent::CAUSE_FALL, 2));
        $this->getWorld()->addSound($player->getPosition(), new EndermanTeleportSound());
        $this->flagForDespawn();
    }

    public function isFence(): bool
    {
        $block = $this->getWorld()->getBlockAt((int)$this->getPosition()->x, (int)$this->getPosition()->y, (int)$this->getPosition()->z);
        return $block instanceof FenceGate;
    }

    public function isPearling(): bool
    {
        $x = $this->getPosition()->x;
        $z = $this->getPosition()->z;
        $block = $this->getWorld()->getBlockAt((int)$x, (int)$this->getPosition()->y, (int)$z);
        return $block instanceof Slab;
    }
}