<?php

declare(strict_types=1);

namespace hcf\entity\default;

use pocketmine\block\Block;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\VanillaBlocks;
use pocketmine\color\Color;
use pocketmine\entity\Entity;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\effect\InstantEffect;
use pocketmine\entity\projectile\Throwable;
use pocketmine\event\entity\ProjectileHitBlockEvent;
use pocketmine\event\entity\ProjectileHitEvent;
use pocketmine\math\RayTraceResult;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use pocketmine\player\Player;
use pocketmine\world\particle\PotionSplashParticle;
use pocketmine\world\sound\PotionSplashSound;
use pocketmine\item\PotionType;

class SplashPotionEntity extends Throwable {

    protected float $gravity = 0.12; // más alto = cae rápido
    protected float $drag = 0.03;    // más alto = pierde velocidad rápido

    public static function getNetworkTypeId(): string {
        return EntityIds::SPLASH_POTION;
    }

    protected function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(0.25, 0.25); // tamaño real de poción
    }

    // 👇 Reducimos velocidad inicial
    public function shoot(float $dx, float $dy, float $dz, float $speed, float $inaccuracy) : void {
        $fixedSpeed = 0.4; // vanilla-like, más corto
        parent::shoot($dx, $dy, $dz, $fixedSpeed, $inaccuracy);
    }

    protected function onHit(ProjectileHitEvent $event): void {
        $effects = $this->getPotionEffects();
        $hasEffects = true;

        if (count($effects) === 0) {
            $particle = new PotionSplashParticle(PotionSplashParticle::DEFAULT_COLOR());
            $hasEffects = false;
        } else {
            $colors = [];
            foreach ($effects as $effect) {
                $level = $effect->getEffectLevel();
                for ($j = 0; $j < $level; ++$j) {
                    $colors[] = $effect->getColor();
                }
            }
            $particle = new PotionSplashParticle(Color::mix(...$colors));
        }

        $this->getWorld()->addParticle($this->location, $particle);
        $this->broadcastSound(new PotionSplashSound());

        if (!$hasEffects) {
            // Agua apaga fuego
            if ($event instanceof ProjectileHitBlockEvent and $this->getPotionType()->equals(PotionType::WATER())) {
                $blockIn = $event->getBlockHit()->getSide($event->getRayTraceResult()->getHitFace());

                if ($blockIn->getTypeId() === BlockTypeIds::FIRE) {
                    $this->getWorld()->setBlock($blockIn->getPosition(), VanillaBlocks::AIR());
                }
                foreach ($blockIn->getHorizontalSides() as $horizontalSide) {
                    if ($horizontalSide->getTypeId() === BlockTypeIds::FIRE) {
                        $this->getWorld()->setBlock($horizontalSide->getPosition(), VanillaBlocks::AIR());
                    }
                }
            }
            return;
        }

        // Aplicar efectos a entidades cercanas
        foreach ($this->getWorld()->getNearbyEntities($this->boundingBox->expandedCopy(2, 3, 2), $this) as $entity) {
            if ($entity instanceof Player && $entity->isAlive()) {
                $distanceMultiplier = 0.6; // reduce la potencia según distancia
                foreach ($effects as $effect) {
                    if (!($effect->getType() instanceof InstantEffect)) {
                        $newDuration = (int) round($effect->getDuration() * 0.75 * $distanceMultiplier);
                        if ($newDuration < 20) {
                            continue;
                        }
                        $effect->setDuration($newDuration);
                        $entity->getEffects()->add($effect);
                    } else {
                        $effect->getType()->applyEffect($entity, $effect, $distanceMultiplier, $this);
                    }
                }
            }
        }
    }
}